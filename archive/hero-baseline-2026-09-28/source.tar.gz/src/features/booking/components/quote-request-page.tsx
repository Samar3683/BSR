import { Mail, MessageCircle, Phone } from "lucide-react";

import { Container } from "@/components/layout/container";
import { Section } from "@/components/layout/section";
import { ButtonLink } from "@/components/ui/button";
import { TextLink } from "@/components/ui/text-link";
import { siteConfig } from "@/config/site";

import { quoteRequestContent as content } from "../config/quote-request-content";

/**
 * Quote-request page — Phase 1 structural placeholder (Server Component).
 *
 * It explains the confirmed request flow and offers the real channels that
 * work today. It does not simulate a form or a submission. The later quote
 * request flow replaces the section marked `data-slot="quote-request-form"`.
 */
export function QuoteRequestPage() {
  const { contact } = siteConfig;

  return (
    <Section spacing="md" aria-labelledby="quote-request-title">
      <Container size="text-wide" className="flex flex-col gap-12">
        <header className="flex flex-col gap-4">
          <p className="type-label-sm text-text-secondary">{content.eyebrow}</p>
          <h1 id="quote-request-title" className="type-heading-xl">
            {content.headline}
          </h1>
          <p className="max-w-text type-body-lg text-text-secondary">{content.intro}</p>
        </header>

        <section aria-labelledby="quote-request-steps" className="flex flex-col gap-4">
          <h2 id="quote-request-steps" className="type-heading-md">
            {content.steps.heading}
          </h2>
          <ol className="flex flex-col gap-3">
            {content.steps.items.map((step, index) => (
              <li key={step} className="flex gap-4 type-body-md">
                <span aria-hidden="true" className="type-metadata text-text-muted">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </section>

        <section
          aria-labelledby="quote-request-send"
          data-slot="quote-request-form"
          className="flex flex-col gap-6 rounded-lg border border-border-default bg-surface-secondary p-6 sm:p-8"
        >
          <div className="flex flex-col gap-3">
            <h2 id="quote-request-send" className="type-heading-md">
              {content.send.heading}
            </h2>
            <p className="type-body-md text-text-secondary">{content.send.status}</p>
          </div>

          <div className="flex flex-col gap-3">
            <h3 className="type-label-md">{content.send.includeHeading}</h3>
            <ul className="flex list-disc flex-col gap-1 pl-5 type-body-md text-text-secondary">
              {content.send.include.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col gap-3">
            <div className="flex flex-wrap gap-3">
              <ButtonLink href={contact.whatsappHref} leadingIcon={MessageCircle}>
                {content.send.whatsapp}
                <span className="sr-only"> {content.send.whatsappHint}</span>
              </ButtonLink>
              <ButtonLink href={contact.phoneHref} variant="secondary" leadingIcon={Phone}>
                {content.send.call} {contact.phoneDisplay}
              </ButtonLink>
              <ButtonLink href={`mailto:${contact.email}`} variant="secondary" leadingIcon={Mail}>
                {content.send.email}
              </ButtonLink>
            </div>
            <p className="type-caption text-text-muted">{content.send.note}</p>
          </div>
        </section>

        <TextLink href="/" variant="action" className="self-start">
          {content.back}
        </TextLink>
      </Container>
    </Section>
  );
}
