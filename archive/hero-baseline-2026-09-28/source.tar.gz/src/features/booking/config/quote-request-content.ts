/**
 * Quote-request page copy.
 *
 * ⚠ PLACEHOLDER COPY — not approved marketing copy. It only restates the
 * confirmed request flow (request → BSR review → price, vehicle and timing)
 * and the confirmed details the current request form collects.
 */
export const quoteRequestContent = {
  title: "Richiedi un preventivo",
  eyebrow: "Richiesta di trasporto",
  headline: "Richiedi un preventivo di trasporto",
  intro:
    "Indica dove ritirare e dove consegnare la merce: BSR verifica la richiesta e ti conferma prezzo, veicolo e tempi.",
  steps: {
    heading: "Come funziona",
    items: [
      "Invii i dati di ritiro, consegna e contatto.",
      "BSR verifica la richiesta.",
      "Ricevi la conferma di prezzo, veicolo e tempi.",
    ],
  },
  send: {
    heading: "Invia la richiesta",
    /** Honest status: the online form is a later phase; no submission is simulated. */
    status:
      "Il modulo di richiesta online è in preparazione. Nel frattempo puoi inviare la richiesta direttamente.",
    includeHeading: "Da indicare nella richiesta",
    include: [
      "Nome e cognome",
      "Telefono ed email",
      "Indirizzo di ritiro (via, CAP, città, provincia o paese)",
      "Indirizzo di consegna (via, CAP, città, provincia o paese)",
    ],
    whatsapp: "Scrivici su WhatsApp",
    whatsappHint: "(apre WhatsApp)",
    call: "Chiama",
    email: "Scrivi un'email",
    /** Mirrors the current business statement. TBD: working-hours qualifier. */
    note: "Conferma e prezzo in circa 30 minuti, via WhatsApp ed email.",
  },
  back: "Torna alla pagina principale",
} as const;
