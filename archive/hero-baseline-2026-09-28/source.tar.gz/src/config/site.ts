/**
 * Site-level identity. Deliberately minimal: marketing copy and SEO are
 * defined in later phases.
 */
export const siteConfig = {
  name: "BSR",
  description: "BSR — trasporto merci in Italia.",
  /** Primary market is Italy; confirm when the content language is finalised. */
  lang: "it",
  /** Mirrors --color-carbon (guarded by src/styles/tokens.test.ts). */
  themeColor: "#090b0b",
  labels: {
    skipToContent: "Vai al contenuto principale",
  },
  /** Supplied business contact details — the single source for every page. */
  contact: {
    phoneDisplay: "+39 327 942 7723",
    phoneHref: "tel:+393279427723",
    email: "Bsrtrasporti@gmail.com",
    /** ASSUMED — WhatsApp uses the supplied mobile number; to be confirmed. */
    whatsappHref: "https://wa.me/393279427723",
  },
  routes: {
    quoteRequest: "/preventivo",
  },
} as const;
