import { MAIN_CONTENT_ID } from "@/constants/landmarks";
import { HeroSection } from "@/experiences/home/components/hero-section";

/**
 * Home page (composition only). Phase 1: the hero's engineering foundation
 * with development placeholders; later chapters follow in later phases.
 */
export default function HomePage() {
  return (
    <main id={MAIN_CONTENT_ID} tabIndex={-1}>
      <HeroSection />
    </main>
  );
}
