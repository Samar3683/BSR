import type { Metadata, Viewport } from "next";

import { SkipLink } from "@/components/accessibility/skip-link";
import { siteConfig } from "@/config/site";
import { MAIN_CONTENT_ID } from "@/constants/landmarks";
import { AppProviders } from "@/providers/app-providers";
import { archivo } from "@/styles/fonts";

import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: siteConfig.name,
    template: `%s — ${siteConfig.name}`,
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
};

export const viewport: Viewport = {
  themeColor: siteConfig.themeColor,
  colorScheme: "dark",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang={siteConfig.lang} className={archivo.variable}>
      <body>
        <SkipLink targetId={MAIN_CONTENT_ID} label={siteConfig.labels.skipToContent} />
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
