# Design system

The BSR design system is premium and cinematic in presentation, industrial and precise in
character, and human-centred in interaction.

- **Live reference:** `/dev/design-system`. It is always on in `pnpm dev`. In production it is hidden
  unless `BSR_DESIGN_PREVIEW=true`, and it is marked noindex.
- **Sources of truth:**
  - `src/styles/tokens.css`: primitives and scales.
  - `src/styles/themes.css`: semantic roles per surface.
  - `src/styles/typography.css`: text styles.
  - `src/styles/utilities.css`: layout and interaction utilities.

## Colour

Black and charcoal dominate. White is used for editorial clarity. Red and green are accents with
fixed meanings, and they never compete for the same screen. The site must not read as a flag.

| Colour                   | Meaning                                         | Never                                                  |
| ------------------------ | ----------------------------------------------- | ------------------------------------------------------ |
| Red                      | Primary action (CTA), key brand moments, errors | Decoration, large fields of colour, small text on dark |
| Green                    | Route, progress, active operation, completion   | Buttons or calls to action                             |
| Metal and stone neutrals | Material support, secondary text, borders       | —                                                      |

Components use **semantic roles** only (`bg-surface-elevated`, `text-text-muted`,
`border-border-strong`, `bg-action-primary`, `text-success`, …). Primitives (`carbon`, `red-500`, …)
feed the roles and are not used directly.

### Surfaces

Wrap a subtree in `<Surface tone="…">` (or `<Section tone="…">`). Every role then re-resolves:
text, borders, actions, status and focus.

| Dark (cinematic)        | Light (editorial) |
| ----------------------- | ----------------- |
| `carbon` (page default) | `soft-white`      |
| `graphite`              | `warm-white`      |
| `asphalt`               | `stone`           |

Within a surface there are three layers:

- `background-primary`: the region itself.
- `surface-secondary`: grouped content.
- `surface-elevated`: raised panels.

Fields use `surface-field`. Depth on dark surfaces comes from a faint top highlight and deep
shadow; on light surfaces it comes from a contact shadow (`shadow-ambient`, `shadow-raised`,
`shadow-overlay`). Only floating layers get shadows. Interactive elements never do, because shadows
would clash with the focus halo. Translucency (`overlay-hover`, scrims) exists only where it
communicates state or preserves legibility. There is no decorative glass.

**Contrast** is enforced by `themes.test.ts` on all six surfaces:

- Text roles: ≥ 4.5:1.
- Borders, focus and status graphics: ≥ 3:1.

Brand red `#B32025` is 2.96:1 on carbon, so on dark surfaces red text uses `danger` (`red-300`). The
red fill carries white text at 6.2:1. Emerald is for graphics on light surfaces only. On dark
surfaces, route and progress graphics use `success-graphic` (`green-500`).

## Typography

**Archivo** (SIL OFL), a single variable family with weight 100–900 and width 62–125. It is
self-hosted by `next/font`, uses the Latin subset (full Italian coverage), and has metric-matched
fallbacks. Display and stat styles use the expanded width, which gives an industrial, automotive
voice. Reading styles stay at normal width.

| Group    | Styles                                                                             |
| -------- | ---------------------------------------------------------------------------------- |
| Display  | `type-display-xl`, `type-display-lg`                                               |
| Headings | `type-heading-xl`, `-lg`, `-md`, `-sm`                                             |
| Body     | `type-body-lg`, `-md`, `-sm`                                                       |
| Labels   | `type-label-lg` (buttons), `-md` (form labels, links), `-sm` (eyebrows, uppercase) |
| Figures  | `type-stat-xl`, `-lg` (tabular numbers)                                            |
| Support  | `type-caption`, `type-metadata` (uppercase, tabular: codes and timestamps)         |

- Choose the HTML element for document structure and the `type-*` class for visual hierarchy.
- Sizes are fluid (`clamp`, rem + vw), so they still respond to zoom.
- **Hierarchy:** eyebrow (`label-sm`, muted) → headline → supporting copy (`body-lg`, secondary) →
  metadata → primary CTA → secondary action.
- **Line length:** body copy always sits in a measure (`max-w-text-narrow` 32rem, `max-w-text`
  40rem, `max-w-text-wide` 48rem).

## Layout and spacing

- **Containers** (`<Container size>` or `container-*`): `text-narrow`, `text`, `text-wide`,
  `content` (80rem), `wide` (110rem), `full` (edge to edge). Use one container per region, and
  constrain text inside it with `max-w-text*`.
- **Grid** (`layout-grid`): 4 columns on small screens, 8 from `md`, 12 from `lg`, with a fluid
  `grid-gap`. Place items with `col-span-*`. Use flex or grid directly when that is simpler.
- **Spacing:**
  - Components use the 4px steps `1 2 3 4 6 8 12 16 24 32` (4–128px).
  - Layout spacing is fluid: `gutter`, `grid-gap`, and `section-sm` / `section` / `section-lg` (via
    `<Section spacing>`).
  - Prefer generous space over boxes and dividers.
- **Radius:** `sm` 2px (chips, checkboxes), `md` 4px (controls), `lg` 8px (panels). Pills
  (`rounded-full`) are for status badges only.
- **Breakpoints** (`sm` 40rem … `2xl` 96rem) change layout only. Rendering quality is a separate
  system (`lib/performance`).

### Information density

| Mode      | Where                   | Rule                                                                                                     |
| --------- | ----------------------- | -------------------------------------------------------------------------------------------------------- |
| Cinematic | Scene-driven sections   | One message at a time: display type, one supporting line, at most one CTA                                |
| Editorial | Services, explanations  | Moderate density: headings, body in a measure, figures, secondary actions                                |
| Task      | Booking, forms, contact | Highest clarity: no decoration, no scene motion, light or quiet surfaces, forms in `container-text-wide` |

On mobile, prioritise the task path and readability. Adapt cinematic richness instead of scaling
it down.

## Components

| Primitive                                              | Location                         | Notes                                                                                                                                                                                                                                                                                             |
| ------------------------------------------------------ | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Button`, `ButtonLink`, `IconButton`                   | `components/ui/button.tsx`       | Variants: `primary` (red, one per region), `secondary`, `ghost`, `inverse` (over imagery). Sizes: `sm` 40px (44px on touch), `md` 48px, `lg` 56px. States: hover, pressed (1px press, motion-safe), focus-visible, disabled, `loading` (`aria-busy`, keeps focus). `IconButton` requires `label`. |
| `TextLink`                                             | `components/ui/text-link.tsx`    | `inline` is always underlined. `utility` is for navigation; the current page gets `aria-current` plus a red underline. `action` has label weight and an arrow.                                                                                                                                    |
| `StatusBadge`                                          | `components/ui/status-badge.tsx` | Statuses: `active`, `in-transit`, `complete`, `available`, `delayed`, `error`, `inactive`. Always label + icon + tone.                                                                                                                                                                            |
| `Icon`                                                 | `components/ui/icon.tsx`         | Lucide outline only, 1.75px stroke at every size. Sizes: `sm` 16, `md` 20, `lg` 24. Uses `currentColor`. Decorative unless `label` is given.                                                                                                                                                      |
| `Field`, `Fieldset`                                    | `components/forms/`              | Label above the control, hint before it, message after it with icon and text. `required` is marked in words. ARIA wiring is included.                                                                                                                                                             |
| `TextInput`, `TextArea`, `Select`, `Checkbox`, `Radio` | `components/forms/`              | States: default, hover, focus, filled (same as default), disabled, read-only (dashed), error (`aria-invalid`), success (`data-state`). Selection uses the surface's ink, never red or green. Whole rows are 44px targets.                                                                         |
| `Container`, `Surface`, `Section`                      | `components/layout/`             | Width, environment and vertical rhythm.                                                                                                                                                                                                                                                           |

**Cursor:** native cursors only. There is no custom cursor.

**Icons:** don't mix in filled icons, emoji or other icon sets.

## Focus

The focus style is `:focus-visible`. It has a 2px ring in the surface's `focus` colour (soft white
on dark, carbon on light) with a contrasting halo on both sides. The halo keeps it visible on dark,
light, red, green and imagery backgrounds. Never remove focus without replacing it with something
stronger.

## Motion

Motion is weighted, precise and controlled, with no bounce, springs or elastic effects.

- **Durations:**
  - `instant` 100ms
  - `fast` 160ms
  - `normal` 240ms
  - `slow` 400ms
  - `cinematic` 800ms
- **Easing:**
  - `ui`: state changes
  - `enter`: arrivals, decelerating
  - `exit`: departures, accelerating
  - `cinematic`: scene changes
  - `mechanical`: machinery with a decisive start and stop
- **Categories** (`MOTION_PRESET` for GSAP):
  - `micro`: fast, ui
  - `uiEnter`: normal, enter
  - `uiExit`: fast, exit
  - `reveal`: slow, enter
  - `section`: cinematic
  - `mechanical`: machinery
- **Scroll-linked motion** takes its pace from the user.
- **Controls:** use `transition-ui` for every control state change. Frequent interactions stay fast,
  and motion never blocks input.
- **GSAP** uses the registered eases (`bsr-ui`, `bsr-enter`, …) and `MOTION_PRESET`. Never hand-write
  bézier strings in sections.
- **Reduced motion** is a designed alternative:
  - Transforms and travel are gated with `motion-safe:`, or with `gsap.matchMedia()` using
    `REDUCED_MOTION_QUERY` / `FULL_MOTION_QUERY`.
  - Colour, opacity and state feedback remain.
  - Final states are shown immediately.
  - Lenis doesn't start.

## Layers

Use `z-(--z-*)` only:

| Layer          | Use                              |
| -------------- | -------------------------------- |
| `canvas`       | WebGL scene, beneath HTML        |
| `content`      | Page content                     |
| `cinematic-ui` | HTML synchronised with the scene |
| `sticky`       | Sticky in-page elements          |
| `navigation`   | Site navigation                  |
| `overlay`      | Scrims, drawers                  |
| `modal`        | Dialogs                          |
| `toast`        | Transient notifications          |
| `skip-link`    | Skip link, always on top         |

## Text over cinematic media

Prefer composition first: place text where the scene is quiet. Then use a localised contrast
surface, or `scrim-bottom` / `scrim-top` in the surface's scrim colour. Use text shadow only as a
last resort. Text over motion must still meet 4.5:1 against the worst frame behind it.
